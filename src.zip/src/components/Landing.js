// src/components/Landing.js
import React, { useState } from "react";
import { Link } from 'react-router-dom';
import "./Landing.css";
import avatar from './images/Avatar.gif';

function Landing() {
  const [doctorName, setDoctorName] = useState('XXX');
  const [sidebarVisible, setSidebarVisible] = useState(true);
  const [greetingPosition, setGreetingPosition] = useState('45%');

  const updateName = (name) => {
      const newName = name.trim();
      if (newName) {
          setDoctorName(newName.charAt(0).toUpperCase() + newName.slice(1));
      }
  };

  const toggleSidebar = () => {
      setSidebarVisible(false);
      setGreetingPosition('30%');
  };

  const expandSidebar = () => {
      setSidebarVisible(true);
      setGreetingPosition('45%');
  };

  return (
      <div>

          {sidebarVisible ? (
              <div className="sidebar">
                  <img src={avatar} alt="Doctor's Avatar" id="avatar" />
                  <ul>
                      <li><a href="/patientList" id="patientList">Patient List</a></li>
                      <li><a href="/profile" id="profile">Profile</a></li>
                      <li><a href="/aboutUs" id="aboutUs">About Us</a></li>
                  </ul>
                  <span className="label">DIGIHEALTH</span>
                  <button id="toggleSidebar" onClick={toggleSidebar}></button>
              </div>
          ) : (
              <div className="blankSidebar" id="blankSidebar">
                  <span className="label">DIGIHEALTH</span>
                  <button id="expandSidebar" onClick={expandSidebar}></button>
              </div>
          )}

          <div id="greeting" style={{ left: greetingPosition }}>
              <h1>Hi, Doctor <span id="doctorName">{doctorName}</span>,</h1>
              <h1>Welcome to DIGIHEALTH</h1>

              <input type="text" id="nameInput" placeholder="Enter Doctor's Name" onChange={(e) => updateName(e.target.value)} />
              <button onClick={() => updateName(document.getElementById('nameInput').value)}>Update Name</button>
          </div>

          <button className="newTreatmentButton" onClick={() => window.location.href='newTreatment.html'}>Start New Treatment</button>

          <div id="version">
              <p>Version 1.0</p>
          </div>
      </div>
  );
}

export default Landing;